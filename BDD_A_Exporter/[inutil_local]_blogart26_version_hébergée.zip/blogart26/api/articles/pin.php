<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/config.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/functions/api_guard.php';

header('Content-Type: application/json');

requireAdminApi();

$numArt = (int) ($_POST['numArt'] ?? 0);
$action = $_POST['action'] ?? '';

if (!$numArt || !in_array($action, ['pin', 'unpin'], true)) {
    echo json_encode(['success' => false, 'message' => 'Paramètres invalides']);
    exit;
}

// Vérifier que l’article existe
$article = sql_select("ARTICLE", "numArt", "numArt = $numArt");
if (empty($article)) {
    echo json_encode(['success' => false, 'message' => 'Article introuvable']);
    exit;
}

// Chemin UNIQUE et autorisé
$jsonFile = $_SERVER['DOCUMENT_ROOT'] . '/functions/pinned_article.json';

// Lecture sécurisée
if (file_exists($jsonFile)) {
    $data = json_decode(file_get_contents($jsonFile), true);
    if (!is_array($data)) {
        $data = ['numArt' => null];
    }
} else {
    $data = ['numArt' => null];
}

// Action
if ($action === 'pin') {
    $data['numArt'] = $numArt;
}

if ($action === 'unpin') {
    $data['numArt'] = null;
}

// Écriture
file_put_contents(
    $jsonFile,
    json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
);

echo json_encode(['success' => true]);
exit;

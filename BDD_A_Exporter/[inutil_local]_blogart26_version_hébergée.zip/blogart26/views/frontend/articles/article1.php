<?php
require_once '../../../header.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/config.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/functions/ctrlSaisies.php';

$numArt = (int)($_GET['numArt'] ?? 0);
$article = null;

if ($numArt > 0) {
    $article = sql_select("ARTICLE", "*", "numArt = $numArt");
    $article = $article[0] ?? null;
}

$userLiked = false;
$numMemb = $_SESSION['user']['id'] ?? null;

if ($numMemb && $article) {
    $resultCheck = sql_select("LIKEART", "*", "numMemb = $numMemb AND numArt = $numArt");
    $userLiked = !empty($resultCheck);
}

$commentairesArt = [];
if ($article) {
    $commentairesArt = sql_select("COMMENT", "*", "numArt = $numArt AND attModOK = 1 AND delLogiq = 0", null, "dtCreaCom DESC");
}
?>

<link rel="stylesheet" href="/src/css/article1.css">

<main class="article-page">
  <div class="article-container">

    <a class="back-link" href="<?= ROOT_URL ?>/views/frontend/articles-list.php">← Retour aux articles</a>

    <?php if ($article): ?>

      <section class="article-layout">

        <article class="article-main">
          <div class="article-top">
            <div>
              <h1 class="article-title"><?php e($article['libTitrArt']); ?></h1>
              <div class="article-meta">
                Publié le <?= htmlspecialchars(date('d/m/Y', strtotime($article['dtCreaArt']))); ?>
              </div>
            </div>

            <div class="article-actions">
              <?php if (!empty($_SESSION['user'])): ?>
                <a class="action-btn" href="<?= ROOT_URL ?>/views/frontend/comments/commentaire.php?numArt=<?= (int)$article['numArt']; ?>">
                  Commenter
                </a>
              <?php else: ?>
                <a class="action-btn ghost" href="<?= ROOT_URL ?>/views/backend/security/login.php">
                  Se connecter pour commenter
                </a>
              <?php endif; ?>

              <?php if (!empty($_SESSION['user'])): ?>
                <form action="<?= ROOT_URL ?>/api/likes/create.php" method="POST" class="like-form">
                  <input type="hidden" name="numMemb" value="<?= (int)$numMemb ?>">
                  <input type="hidden" name="numArt" value="<?= (int)$numArt ?>">
                  <input type="hidden" name="frontend" value="true">
                  <?php $likeCount = getLikeCount($numArt); ?>
                  <button type="submit"
                          class="like-btn <?= $userLiked ? 'liked' : '' ?>"
                          title="<?= $userLiked ? 'Retirer le like' : 'Liker' ?>">
                      <span class="heart">♥</span>
                      <span class="like-count"><?= $likeCount ?></span>
                  </button>
                </form>
              <?php else: ?>
                <a class="like-btn ghost" href="<?= ROOT_URL ?>/views/backend/security/login.php" title="Se connecter pour liker">
                  <span class="heart">♥</span>
                </a>
              <?php endif; ?>
            </div>
          </div>

          <p class="article-chapo"><?php e($article['libChapoArt']); ?></p>

          <?php if (!empty($article['urlPhotArt'])): ?>
            <div class="article-image">
              <img src="<?= ROOT_URL ?>/src/uploads/<?= htmlspecialchars($article['urlPhotArt']); ?>" alt="<?= htmlspecialchars($article['libTitrArt']); ?>" style="max-width: 400px; height: auto; display: block; margin: 20px auto;">
            </div>
          <?php endif; ?>

          <div class="article-divider"></div>
          <?php if (!empty($article['libAccrochArt'])): ?>
            <p class="article-accroche"><?php e($article['libAccrochArt']); ?></p>
          <?php endif; ?>

          <?php if (!empty($article['parag1Art'])): ?>
            <p class="article-paragraph"><?php e($article['parag1Art']); ?></p>
          <?php endif; ?>

          <?php if (!empty($article['libSsTitr1Art'])): ?>
            <h3 class="article-subtitle"><?php e($article['libSsTitr1Art']); ?></h3>
          <?php endif; ?>

          <?php if (!empty($article['parag2Art'])): ?>
            <p class="article-paragraph"><?php e($article['parag2Art']); ?></p>
          <?php endif; ?>

          <?php if (!empty($article['libSsTitr2Art'])): ?>
            <h3 class="article-subtitle"><?php e($article['libSsTitr2Art']); ?></h3>
          <?php endif; ?>

          <?php if (!empty($article['parag3Art'])): ?>
            <p class="article-paragraph"><?php e($article['parag3Art']); ?></p>
          <?php endif; ?>

          <?php if (!empty($article['libConclArt'])): ?>
            <p class="article-conclusion">
              <?php e($article['libConclArt']); ?>
            </p>
          <?php endif; ?>

          <div class="article-divider"></div>
          <a class="more-link" href="<?= ROOT_URL ?>/views/frontend/articles-list.php">
            Voir plus d’articles →
          </a>
        </article>

        <aside class="comments-panel">
          <div class="comments-head">
            <h2>Commentaires</h2>
            <span class="comments-count"><?= count($commentairesArt) ?></span>
          </div>

          <?php if (!empty($commentairesArt)): ?>
            <div class="comments-list">
              <?php foreach ($commentairesArt as $commentaire): ?>
                <?php
                  $membre = sql_select("MEMBRE", "pseudoMemb", "numMemb = " . (int)$commentaire['numMemb']);
                  $pseudo = $membre[0]['pseudoMemb'] ?? 'Utilisateur supprimé';
                ?>
                <div class="comment">
                  <div class="comment-head">
                    <strong class="comment-user"><?= htmlspecialchars($pseudo); ?></strong>
                    <span class="comment-date"><?= htmlspecialchars(date('d/m/Y H:i', strtotime($commentaire['dtCreaCom']))); ?></span>
                  </div>
                  <p class="comment-text"><?php e($commentaire['libCom']); ?></p>
                </div>
              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <p class="comments-empty">Aucun commentaire pour cet article.</p>
          <?php endif; ?>

        </aside>

      </section>

    <?php else: ?>
      <div class="article-notfound">Article introuvable.</div>
    <?php endif; ?>

  </div>

    <?php
  $articleId = isset($_GET['numArt']) ? (int)$_GET['numArt'] : 0;

  if ($articleId <= 0) {
      http_response_code(404);
      echo "Article invalide";
      exit;
  }

  $article = sql_select('ARTICLE', '*', 'numArt = ' . $articleId);

  if (empty($article)) {
      http_response_code(404);
      echo "Article non trouvé";
      exit;
  }

  $article = $article[0];

  $titreArticle = htmlspecialchars($article['libTitrArt'], ENT_QUOTES, 'UTF-8');
  $urlArticle = ROOT_URL . '/views/frontend/articles/article1.php?numArt=' . $articleId;
  $encodedUrl = urlencode($urlArticle);
  $encodedTitle = urlencode($titreArticle);
  ?>

  <div class="container">
    <h2 class="TRS">Partager cet article :</h2>
    <a href="https://www.facebook.com/sharer/sharer.php?u=<?= $encodedUrl ?>"
      target="_blank" rel="noopener noreferrer" class="btn btn-primary">
        Facebook
    </a>

    <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?= $encodedUrl ?>&title=<?= $encodedTitle ?>"
      target="_blank" rel="noopener noreferrer" class="btn btn-primary">
        LinkedIn
    </a>

    <a href="https://api.whatsapp.com/send?text=<?= $encodedTitle ?>%20<?= $encodedUrl ?>"
      target="_blank" rel="noopener noreferrer" class="btn btn-primary">
        WhatsApp
    </a>
  </div>
</main>

<?php require_once '../../../footer.php'; ?>
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('ROOT', $_SERVER['DOCUMENT_ROOT']);
define('ROOT_URL', 'https://' . $_SERVER['HTTP_HOST']);

// BDD INFINITYFREE (OBLIGATOIRE)
define('DB_HOST', 'sql308.infinityfree.com');
define('DB_NAME', 'if0_41051795_blogart26');
define('DB_USER', 'if0_41051795');
define('DB_PASS', 'XdXnCHVySfFVhpb');

// DEBUG
define('APP_DEBUG', true);

if (APP_DEBUG) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
}

require_once ROOT . '/functions/global.inc.php';
require_once ROOT . '/functions/security.php';
<?php
define('SQL_HOST', getenv('DB_HOST'));
define('SQL_USER', getenv('DB_USER'));
define('SQL_PWD', getenv('DB_PASSWORD'));
define('SQL_DB', getenv('DB_DATABASE'));
?>
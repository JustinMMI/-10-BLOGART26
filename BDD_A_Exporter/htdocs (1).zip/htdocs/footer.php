<footer class="site-footer">
  <div class="footer-inner">

    <div class="footer-brand">
      <span class="footer-title">Bordeaux Gastronomie</span>
      <span class="footer-separator"></span>
      <p class="footer-tagline">
        Le regard gourmand sur la scène bordelaise
      </p>
    </div>

    <div class="footer-bottom">
      <div class="footer-links">
        <a href="/views/frontend/rgpd/rgpd.php">RGPD</a>
        <a href="/views/frontend/rgpd/cgu.php">CGU</a>
        <a href="/views/frontend/contact.php">Contactez-nous</a>
      </div>
      <p>
        &copy; 2026 Bordeaux Gastronomie — Tous droits réservés
      </p>
    </div>

  </div>
</footer>

<!-- JS -->
<script src="/functions/motsCles.js"></script>

<script>
  const burger = document.getElementById("burger");
  if (burger) {
    burger.addEventListener("click", function () {
      document.getElementById("navbar")?.classList.toggle("open");
    });
  }
</script>












<!-- KONAMI CODE -->


<style>
#konami-overlay {
    position: fixed;
    inset: 0;
    background: black;
    opacity: 0;
    pointer-events: none;
    z-index: 99998;
    transition: opacity 1.2s ease;
}

#konami-overlay.active {
    opacity: 1;
    pointer-events: auto;
}

#dvd-logo {
    position: fixed;
    width: 250px;
    height: auto;
    z-index: 99999;
    pointer-events: none;
    will-change: transform, filter;
    mix-blend-mode: screen;
    transition: filter 0.25s linear;
}


#dvd-logo {
    image-rendering: auto;
    transition: filter 0.2s linear;
}

</style>

<script>
(function () {
    const konami = [
        'ArrowUp','ArrowUp',
        'ArrowDown','ArrowDown',
        'ArrowLeft','ArrowRight',
        'ArrowLeft','ArrowRight',
        'b','a'
    ];

    let index = 0;
    let active = false;
    let animId = null;
    let logo, overlay;

    let x = 100, y = 100;
    let vx = 2.5, vy = 2.5;

    document.addEventListener('keydown', (e) => {
        const key = e.key.toLowerCase();

        if (key === konami[index].toLowerCase()) {
            index++;
            if (index === konami.length) {
                toggleEasterEgg();
                index = 0;
            }
        } else {
            index = 0;
        }
    });

    function toggleEasterEgg() {
        if (active) {
            stop();
        } else {
            start();
        }
    }

    function start() {
        active = true;

        // Overlay noir
        overlay = document.createElement('div');
        overlay.id = 'konami-overlay';
        document.body.appendChild(overlay);

        requestAnimationFrame(() => overlay.classList.add('active'));

        // Logo DVD
        logo = document.createElement('img');
        logo.id = 'dvd-logo';
        logo.src = '/src/images/mmi-bordeaux_Blanc.png';
        logo.style.left = '0';
        logo.style.top = '0';

        // IMPORTANT : attendre le chargement réel de l’image
        logo.onload = () => {
            document.body.appendChild(logo);

            const w = logo.offsetWidth;
            const h = logo.offsetHeight;

            x = Math.random() * (window.innerWidth - w);
            y = Math.random() * (window.innerHeight - h);

            // VITESSE DIAGONALE GARANTIE
            vx = Math.random() > 0.5 ? 1.2 : -1.2;
            vy = Math.random() > 0.5 ? 1.2 : -1.2;

            animate();
        };
    }


    function stop() {
        active = false;
        cancelAnimationFrame(animId);

        if (overlay) {
            overlay.classList.remove('active');
            setTimeout(() => overlay.remove(), 1200);
        }
        if (logo) logo.remove();
    }

    function animate() {
        if (!active || !logo) return;

        const w = logo.offsetWidth;
        const h = logo.offsetHeight;

        x += vx;
        y += vy;

        let bounced = false;

        if (x <= 0 || x + w >= window.innerWidth) {
            vx *= -1;
            bounced = true;
        }

        if (y <= 0 || y + h >= window.innerHeight) {
            vy *= -1;
            bounced = true;
        }

        if (bounced) changeColor();

        logo.style.transform = `translate(${x}px, ${y}px)`;

        animId = requestAnimationFrame(animate);
    }


    function changeColor() {
        const hue = Math.floor(Math.random() * 360);

        logo.style.filter = `
            drop-shadow(0 0 12px hsl(${hue}, 100%, 60%))
            drop-shadow(0 0 24px hsl(${hue}, 100%, 60%))
            brightness(1.2)
        `;
    }
})();
</script>


</body>
</html>

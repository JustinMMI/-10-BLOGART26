<?php
function sql_select($table, $attributs='*', $where=null, $group=null, $order=null, $limit=null)
{
    global $DB;

    if (!$DB) {
        sql_connect();
    }

    $table = trim($table);

    /* =========
       CAS 1 : table simple (ARTICLE)
       ========= */
    if (preg_match('/^[a-z_]+$/i', $table)) {
        $from = strtolower($table);
    }

    /* =========
       CAS 2 : table + alias (ARTICLE a)
       ========= */
    elseif (preg_match('/^([a-z_]+)\s+([a-z_]+)$/i', $table, $m)) {
        $from = strtolower($m[1]) . ' ' . $m[2];
    }

    /* =========
       CAS 3 : jointures ou clauses complexes
       ========= */
    else {
        // normalise uniquement les noms de tables
        $from = preg_replace_callback(
            '/\b([a-z_]+)\b/i',
            function ($matches) {
                static $sqlKeywords = [
                    'select','from','where','join','inner','left','right',
                    'on','group','order','by','as','distinct'
                ];

                $word = strtolower($matches[1]);
                return in_array($word, $sqlKeywords, true)
                    ? $word
                    : $word;
            },
            $table
        );
    }

    $query = "SELECT $attributs FROM $from";

    if ($where)  $query .= " WHERE $where";
    if ($group)  $query .= " GROUP BY $group";
    if ($order)  $query .= " ORDER BY $order";
    if ($limit)  $query .= " LIMIT $limit";

    // DEBUG temporaire si besoin
    // echo $query; exit;

    $res = $DB->query($query);

    if ($res === false) {
        $err = $DB->errorInfo();
        throw new Exception($err[2]);
    }

    return $res->fetchAll(PDO::FETCH_ASSOC);
}

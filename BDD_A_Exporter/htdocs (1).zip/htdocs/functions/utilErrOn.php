<?php
//  Affichage des messages d'erreurs : Mode DEV
ini_set('display_errors','on');
ini_set('display_startup_errors','on');
error_reporting(E_ALL);
?>
<?php
require_once '../../header.php';

if (empty($_SESSION['user'])) {
    header('Location: ../../views/backend/security/login.php');
    exit;
}

$numMemb = (int) $_SESSION['user']['id'];
$message = '';

/* =========================
   ARTICLES LIKÉS
========================= */
$likedArticles = sql_select(
    "LIKEART l INNER JOIN ARTICLE a ON l.numArt = a.numArt",
    "l.numMemb, l.numArt, l.likeA, a.libTitrArt, a.libChapoArt",
    "l.numMemb = $numMemb AND l.likeA = 1",
    null,
    "l.numArt DESC"
);

/* =========================
   SUPPRESSION LIKE
========================= */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['action']) &&
    $_POST['action'] === 'removeLike'
) {
    $numArt = (int) ($_POST['numArt'] ?? 0);

    if ($numArt > 0) {
        sql_delete(
            "LIKEART",
            "numMemb = $numMemb AND numArt = $numArt"
        );

        header('Location: liked-articles.php?success=1');
        exit;
    }
}

if (isset($_GET['success'])) {
    $message = "Like retiré avec succès.";
}
?>

<link rel="stylesheet" href="/src/css/liked-articles.css">

<main class="liked-page">

  <section class="liked-hero">
    <h1>Mes coups de cœur</h1>
    <span class="liked-separator"></span>
    <p>Les articles que vous avez choisis de garder en mémoire</p>
  </section>

  <section class="liked-timeline container">

    <?php if ($message): ?>
      <div class="liked-message">
        <?= htmlspecialchars($message) ?>
      </div>
    <?php endif; ?>

    <?php if (!empty($likedArticles)): ?>
      <div class="timeline">

        <?php foreach ($likedArticles as $article): ?>
          <?php $numArt = (int) $article['numArt']; ?>

          <article class="timeline-item">

            <div class="timeline-marker">♥</div>

            <div class="timeline-content">
              <h2><?php e($article['libTitrArt']); ?></h2>

              <p><?php e($article['libChapoArt']); ?></p>

              <div class="timeline-actions">
                <a href="/views/frontend/articles/article1.php?numArt=<?= $numArt ?>">
                  Lire l’article →
                </a>

                <form method="POST">
                  <input type="hidden" name="action" value="removeLike">
                  <input type="hidden" name="numArt" value="<?= $numArt ?>">
                  <button type="submit">
                    Retirer le like
                  </button>
                </form>
              </div>

              <br>

              <a class="more-link" href="<?= ROOT_URL ?>/views/frontend/articles-list.php">
                Voir plus d’articles →
              </a>
            </div>

          </article>
        <?php endforeach; ?>

      </div>
    <?php else: ?>
      <div class="liked-empty">
        <p>Vous n’avez encore aimé aucun article.</p>
        <a href="/views/frontend/articles-list.php">
          Découvrir les articles →
        </a>
      </div>
    <?php endif; ?>

  </section>
</main>

<?php require_once '../../footer.php'; ?>
